Files present in the package:

There are main files are:
� Start.java: The main files that calls which algorithm to perform and select the file to perform the search on
� Element_Node.java: This file contains the structure and basic functions for the nodes. 
� NodeQueue.java: The file consists of the basic queue operations like enqueue, dequeue, additem, etc.
� Comparator_Node.java: This file has comparing costs of adjacent nodes 
� Successor.java: Print and successor functions are present in this file. 
� Point.java: Returns a coordinate as a tuple
� Algorithms.java: This file has the logic for all the algorithms (BFS, RBFS and Astar) and the definition of the heuristic function.
� Tile.java: has the tile class with the latitude and longitude as attributes for every tile.

How to run the file:

The program accepts two command line arugments in teh following format:

<ALG> <FILE>

In eclipse, you can give these in the Run Configurtaions. 
ALG -> denotes which Algorith to run: 
	BFS - Breadth First Seach
	RBFS - Recursive Best First Search
	Astar - A star algorithm
FILE -> denotes the FULL path of the file to run as a path or puzzle

Run the Start.java file.

PS: if the path is too big, you can comment the print statement in the Successor class in the output_report function